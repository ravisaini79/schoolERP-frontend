import React from 'react'

function Index() {
    return (
        <div>
            All Teachers Ppage
        </div>
    )
}

export default Index
