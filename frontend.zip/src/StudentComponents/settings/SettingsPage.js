import React from 'react'
import Settings from '../../components/settings/Settings'

function SettingsPage() {
    return (
        <div>
           <Settings />
        </div>
    )
}

export default SettingsPage
