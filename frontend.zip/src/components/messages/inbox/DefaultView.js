import React from 'react'

function DefaultView() {
    return (
        <div className="default__chat">
            <div>
            <h1>Welcome , Admin </h1>
            <h4>Messaging Chat system</h4>
            </div>
       </div>
    )
}

export default DefaultView
